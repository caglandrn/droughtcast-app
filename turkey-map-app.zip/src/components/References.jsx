import React from "react";

const References = () => (
  <div style={{ padding: "1rem" }}>
    <h1>References</h1>
    <p>This web app shows an interactive Turkey map. It’s built with React and Vite!</p>
  </div>
);

export default References;
