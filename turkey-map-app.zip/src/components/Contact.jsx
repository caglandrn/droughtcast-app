import React from "react";

const Contact = () => (
  <div style={{ padding: "1rem" }}>
    <h1>Contact</h1>
    <p>This web app shows an interactive Turkey map. It’s built with React and Vite!</p>
  </div>
);

export default Contact;
